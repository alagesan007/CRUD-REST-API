var express = require('express');
var bodyparser = require('body-parser');
var fs = require('fs');
const app = express();

app.use(bodyparser.urlencoded({
    extended:true
}));
app.get('/',function(req,res){
    res.sendFile(__dirname + '/index.html')
});
app.post('/adduser',function(req,res){
    var key = req.body.userid;
    var username = req.body.username;
    var dob = req.body.dob;
    var prof = req.body.prof;
    var obj = {};
    var newuser = {
        "name" : username,
        "dob" : dob,
        "prof" : prof
    }
    obj[key] = newuser;

    fs.readFile("users.json","utf8",function(req,data){
        data = JSON.parse(data);
        data[key] = obj[key];
        console.log(data);
        var updateuser = JSON.stringify(data);
        fs.writeFile('users.json',updateuser,function(err){
            res.end( JSON.stringify(data));
        });
    });
});
app.post("/particularUserData",function(req,res){
    fs.readFile("users.json","utf8",function(err,data){
        var users = JSON.parse(data);
        var user = users[req.body.urid];
        console.log("your user infondetails..");
        console.log(user);
        res.end(JSON.stringify(user));
    })
})

app.post("/deleteUserData",function(req,res){
    fs.readFile("users.json","utf8",function(err,data){
        data = JSON.parse(data);
        delete data[req.body.delid];
        console.log("id is deleted succesfully");
        console.log(data);
        var updateuser = JSON.stringify(data);
        fs.writeFile('users.json',updateuser,function(err){
            res.end( JSON.stringify(data));
        });
    })
})
app.get('/showUserData',function(req,res){
    fs.readFile('users.json',function(req,data){
        console.log(data);
        res.end(data);
    })
}); 
app.listen(3000,function(){
    console.log("server is  running now in port 3000");
});